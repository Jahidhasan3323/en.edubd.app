window.$ = window.jQuery = require('jquery');
require('bootstrap-sass');
require('./jquery.metisMenu.js');
require('./custom.js');
require('./select2.js');