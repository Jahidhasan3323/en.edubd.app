<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WmGeneralTextType extends Model
{
    protected $guarded = array();
}
