<?php

namespace App\Http\TriatContainer;

use Illuminate\Http\Request;

trait SubjectValidation
{
  
}
