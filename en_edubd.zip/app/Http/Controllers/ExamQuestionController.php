<?php

namespace App\Http\Controllers;

use App\exam_question;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExamQuestionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\exam_question  $exam_question
     * @return \Illuminate\Http\Response
     */
    public function show(exam_question $exam_question)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\exam_question  $exam_question
     * @return \Illuminate\Http\Response
     */
    public function edit(exam_question $exam_question)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\exam_question  $exam_question
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, exam_question $exam_question)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\exam_question  $exam_question
     * @return \Illuminate\Http\Response
     */
    public function destroy(exam_question $exam_question)
    {
        //
    }
}
