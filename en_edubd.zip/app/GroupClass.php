<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class GroupClass extends Model
{
    protected $fillable=['name'];
}
